
import React, { useState, useEffect, useCallback } from 'react';
import { NowPlaying } from './components/NowPlaying';
import { PlayerControls } from './components/PlayerControls';
import { StreamSelector } from './components/StreamSelector';
import { ClientManager } from './components/ClientManager';
import { SyncedDevices } from './components/SyncedDevices';
import { Settings as SettingsModal } from './components/Settings';
import { getInitialData } from './services/mockData';
import type { Stream, Client, Settings } from './types';
import { useAudioSync } from './hooks/useAudioSync';

const MY_CLIENT_ID = 'client-1';
const VOLUME_STEP = 5;

const App: React.FC = () => {
  const [streams, setStreams] = useState<Stream[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [preMuteGroupVolumes, setPreMuteGroupVolumes] = useState<Record<string, Record<string, number>>>({});
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settings, setSettings] = useState<Settings>({
    integrations: {
      airplay: true,
      spotifyConnect: false,
      snapcast: true,
      visualizer: false,
    },
    theme: {
      mode: 'dark',
      accent: 'purple',
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleSystemThemeChange = (e: MediaQueryListEvent) => {
        if (settings.theme.mode === 'system') {
            root.setAttribute('data-theme', e.matches ? 'dark' : 'light');
        }
    };

    if (settings.theme.mode === 'system') {
        root.setAttribute('data-theme', mediaQuery.matches ? 'dark' : 'light');
        mediaQuery.addEventListener('change', handleSystemThemeChange);
    } else {
        root.setAttribute('data-theme', settings.theme.mode);
        mediaQuery.removeEventListener('change', handleSystemThemeChange);
    }

    root.setAttribute('data-accent', settings.theme.accent);
    
    return () => {
        mediaQuery.removeEventListener('change', handleSystemThemeChange);
    };
}, [settings.theme]);

  const myClient = clients.find(c => c.id === MY_CLIENT_ID);
  const currentStream = streams.find(s => s.id === myClient?.currentStreamId);

  const syncedClients = clients.filter(c => c.id !== MY_CLIENT_ID && c.currentStreamId === myClient?.currentStreamId);
  const otherClients = clients.filter(c => c.currentStreamId !== myClient?.currentStreamId);

  const updateStreamProgress = useCallback((streamId: string, newProgress: number) => {
    setStreams(prevStreams =>
      prevStreams.map(s =>
        s.id === streamId
          ? { ...s, progress: Math.min(newProgress, s.currentTrack.duration) }
          : s
      )
    );
  }, []);

  useAudioSync(currentStream, updateStreamProgress);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      const { initialStreams, initialClients } = await getInitialData();
      setStreams(initialStreams);
      setClients(initialClients);
      setIsLoading(false);
    };
    fetchData();
  }, []);

  const handleVolumeChange = (clientId: string, volume: number) => {
    setClients(prevClients =>
      prevClients.map(c => (c.id === clientId ? { ...c, volume } : c))
    );
  };

  const handleGroupVolumeAdjust = (streamId: string | null, direction: 'up' | 'down') => {
    if (!streamId) return;
    const adjustment = direction === 'up' ? VOLUME_STEP : -VOLUME_STEP;

    setClients(prevClients => {
      return prevClients.map(c => {
        if (c.currentStreamId === streamId) {
          const newVolume = Math.max(0, Math.min(100, c.volume + adjustment));
          return { ...c, volume: newVolume };
        }
        return c;
      });
    });
  };

  const handleGroupMute = (streamId: string | null) => {
    if (!streamId) return;

    const isMuted = preMuteGroupVolumes[streamId];

    if (isMuted) {
      setClients(prevClients =>
        prevClients.map(c =>
          c.currentStreamId === streamId && preMuteGroupVolumes[streamId][c.id] !== undefined
            ? { ...c, volume: preMuteGroupVolumes[streamId][c.id] }
            : c
        )
      );
      setPreMuteGroupVolumes(prev => {
        const newPreMuteVolumes = { ...prev };
        delete newPreMuteVolumes[streamId];
        return newPreMuteVolumes;
      });
    } else {
      const volumesToStore: Record<string, number> = {};
      clients.forEach(c => {
        if (c.currentStreamId === streamId) {
          volumesToStore[c.id] = c.volume;
        }
      });

      if (Object.keys(volumesToStore).length > 0) {
        setPreMuteGroupVolumes(prev => ({
          ...prev,
          [streamId]: volumesToStore,
        }));
      }

      setClients(prevClients =>
        prevClients.map(c =>
          c.currentStreamId === streamId ? { ...c, volume: 0 } : c
        )
      );
    }
  };

  const handleStreamChange = (clientId: string, streamId: string | null) => {
    setClients(prevClients =>
      prevClients.map(c => (c.id === clientId ? { ...c, currentStreamId: streamId } : c))
    );
  };

  const handlePlayPause = () => {
    if (!currentStream) return;
    setStreams(prevStreams =>
      prevStreams.map(s =>
        s.id === currentStream.id ? { ...s, isPlaying: !s.isPlaying } : s
      )
    );
  };

  const handleSkip = (direction: 'next' | 'prev') => {
    console.log(`Skipping ${direction}`);
  };

  if (isLoading || !myClient) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[var(--bg-primary)]">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-5xl text-[var(--accent-color)]"></i>
          <p className="mt-4 text-lg text-[var(--text-secondary)]">Loading Audio System...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)] text-[var(--text-primary)] font-sans p-4 md:p-8 flex flex-col">
      <div className="w-full max-w-7xl mx-auto flex-grow grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <div className="lg:col-span-2 bg-[var(--bg-secondary)] p-6 rounded-2xl shadow-2xl flex flex-col">
          <div className="border-b border-[var(--border-color)] pb-4">
            <StreamSelector
              streams={streams}
              currentStreamId={myClient.currentStreamId}
              onSelectStream={(streamId) => handleStreamChange(myClient.id, streamId)}
            />
          </div>
          {currentStream ? (
            <div className="flex-grow flex flex-col">
              <div className="space-y-6">
                <NowPlaying stream={currentStream} />
                <PlayerControls
                  stream={currentStream}
                  volume={myClient.volume}
                  onVolumeChange={(vol) => handleVolumeChange(myClient.id, vol)}
                  onPlayPause={handlePlayPause}
                  onSkip={handleSkip}
                />
              </div>
              <SyncedDevices 
                clients={syncedClients}
                streams={streams}
                onVolumeChange={handleVolumeChange}
                onStreamChange={handleStreamChange}
                onGroupVolumeAdjust={(dir) => handleGroupVolumeAdjust(myClient.currentStreamId, dir)}
                onGroupMute={() => handleGroupMute(myClient.currentStreamId)}
              />
            </div>
          ) : (
            <div className="flex-grow flex flex-col items-center justify-center bg-[var(--bg-secondary)] rounded-lg p-8 h-full min-h-[300px]">
              <i className="fas fa-music text-6xl text-[var(--text-muted)] mb-4"></i>
              <h2 className="text-2xl font-semibold text-[var(--text-secondary)]">No Stream Selected</h2>
              <p className="text-[var(--text-muted)] mt-2">Choose a source to begin.</p>
            </div>
          )}
        </div>

        <div className="space-y-8">
          <div className="bg-[var(--bg-secondary)] p-6 rounded-2xl shadow-2xl">
            <h2 className="text-2xl font-bold text-[var(--accent-color)] border-b border-[var(--border-color)] pb-4 mb-4">Other Streams &amp; Devices</h2>
            <ClientManager
              clients={otherClients}
              streams={streams}
              myClientStreamId={myClient.currentStreamId}
              onVolumeChange={handleVolumeChange}
              onStreamChange={handleStreamChange}
              onGroupVolumeAdjust={handleGroupVolumeAdjust}
              onGroupMute={handleGroupMute}
            />
          </div>
        </div>
      </div>
      <footer className="w-full max-w-7xl mx-auto grid grid-cols-3 items-center text-[var(--text-muted)] mt-12 text-sm">
        <div>{/* Spacer */}</div>
        <p className="text-center">Sync Audio Controller &copy; 2024</p>
        <div className="flex justify-end">
            <button 
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 rounded-full hover:bg-[var(--bg-secondary)]"
              aria-label="Open Settings"
            >
              <i className="fas fa-cog text-lg"></i>
            </button>
        </div>
      </footer>
      {isSettingsOpen && (
        <SettingsModal 
            settings={settings}
            onSettingsChange={setSettings}
            onClose={() => setIsSettingsOpen(false)}
        />
      )}
    </div>
  );
};

export default App;
